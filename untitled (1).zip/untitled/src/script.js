document.addEventListener("DOMContentLoaded", function () {
    const authSection = document.getElementById("auth-section");
    const streamMain = document.getElementById("stream-main");
    const authActionBtn = document.getElementById("auth-action-btn");
    const authUsername = document.getElementById("auth-username");
    const authPassword = document.getElementById("auth-password");
    const authError = document.getElementById("auth-error");
    const toggleRegisterLink = document.getElementById("toggle-register-link");
    const registerBtn = document.getElementById("register-btn");
    const registerUsername = document.getElementById("register-username");
    const registerPassword = document.getElementById("register-password");
    const registerError = document.getElementById("register-error");

    let users = JSON.parse(localStorage.getItem('users')) || {}; // Retrieve registered users from localStorage
    let currentUser = localStorage.getItem('currentUser') || ""; // Simulate persistent session

    function isValidUsername(username) {
        const usernameRegex = /^[a-zA-Z0-9]{3,15}$/;
        return usernameRegex.test(username);
    }

    function isValidPassword(password) {
        const passwordRegex = /^(?=.*[A-Z])(?=.*[0-9])(?=.*[a-z]).{6,}$/;
        return passwordRegex.test(password);
    }

    function showStreamPage() {
        authSection.style.display = "none";
        streamMain.style.display = "flex";
    }

    function authenticate(username, password) {
        if (users[username] && users[username] === password) {
            currentUser = username;
            localStorage.setItem('currentUser', username); // Simulate user session
            showStreamPage();
        } else {
            authError.textContent = "Nom d'utilisateur ou mot de passe incorrect";
            authError.style.display = "block";
        }
    }

    function register(username, password) {
        if (!isValidUsername(username)) {
            registerError.textContent = "Nom d'utilisateur invalide (3-15 caractères, lettres et chiffres seulement)";
            registerError.style.display = "block";
        } else if (!isValidPassword(password)) {
            registerError.textContent = "Le mot de passe doit avoir au moins 6 caractères, avec une majuscule, une minuscule et un chiffre";
            registerError.style.display = "block";
        } else if (users[username]) {
            registerError.textContent = "Cet utilisateur existe déjà";
            registerError.style.display = "block";
        } else {
            users[username] = password;
            localStorage.setItem('users', JSON.stringify(users)); // Store new user in localStorage
            alert("Inscription réussie! Vous pouvez vous connecter.");
            toggleAuthForm();
        }
    }

    function toggleAuthForm() {
        authSection.querySelector(".auth-container").style.display = "block";
        authSection.querySelector(".register-container").style.display = "none";
        authError.style.display = "none";
    }

    authActionBtn.addEventListener("click", function () {
        const username = authUsername.value.trim();
        const password = authPassword.value.trim();
        authenticate(username, password);
    });

    registerBtn.addEventListener("click", function () {
        const username = registerUsername.value.trim();
        const password = registerPassword.value.trim();
        register(username, password);
    });

    toggleRegisterLink.addEventListener("click", function (e) {
        e.preventDefault();
        authSection.querySelector(".auth-container").style.display = "none";
        authSection.querySelector(".register-container").style.display = "block";
    });

    // Chat functionalities
    const chatMessages = document.getElementById("chat-messages");
    const chatInput = document.getElementById("chat-input");
    const sendBtn = document.getElementById("send-btn");

    function addMessage(username, message) {
        const messageElement = document.createElement("div");
        messageElement.innerHTML = `<strong>${username}:</strong> ${message}`;
        chatMessages.appendChild(messageElement);
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    sendBtn.addEventListener("click", function () {
        const message = chatInput.value.trim();
        if (message) {
            addMessage(currentUser, message);
            chatInput.value = "";
        }
    });

    chatInput.addEventListener("keypress", function (event) {
        if (event.key === "Enter") {
            sendBtn.click();
        }
    });

    // Emoji picker
    document.getElementById("emoji-picker").addEventListener("click", function (e) {
        if (e.target.classList.contains("emoji-btn")) {
            chatInput.value += e.target.textContent;
            chatInput.focus();
        }
    });

    // Simulate viewer count with realistic fluctuations
    const viewerCount = document.getElementById("count");
    setInterval(() => {
        const fluctuation = Math.floor(Math.random() * 10) - 5;
        let currentCount = parseInt(viewerCount.textContent);
        viewerCount.textContent = Math.max(currentCount + fluctuation, 0); // Ensure non-negative count
    }, 3000);

    // Check if user is already logged in
    if (currentUser) {
        showStreamPage();
    }
});
